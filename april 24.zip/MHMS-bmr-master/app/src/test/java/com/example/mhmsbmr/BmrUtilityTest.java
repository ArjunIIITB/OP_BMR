package com.example.mhmsbmr;

import com.example.mhmsbmr.model.Composition;
import com.example.mhmsbmr.utility.BmrCreateCompositionUtility;
import com.example.mhmsbmr.utility.BmrUtility;
import com.example.mhmsbmr.utility.MHPAssignmentUtility;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class BmrUtilityTest {

    @Test
    public void getVirtualFolderByPersonId(){
        String loginToken = "eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3MDYxNjQ2LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODcwMTg0NDYsInNlc3Npb25JZCI6ImRhZDVhYTIyLTViZWMtNDg0Ni05NDAyLTcwODFlOWZlMjg1YyIsInVzZXJOYW1lIjoicHJhc2hhbnQiLCJvcmdVVUlEIjoiNGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyIiwibmJmIjoxNTg3MDE4NDQ2LCJvcmdSb2xlIjoiTUhQcm9mZXNzaW9uYWwiLCJzZXNzaW9uVG9rZW4iOiJTZXNzaW9uSWQ6MTcyLjMxLjUuMTMjcHJhc2hhbnQ6NGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyOk1ITVM6TUhQcm9mZXNzaW9uYWwjMTU4NzAxODQ0NjIxNyMtODI5MDAxMzE2IzY3MiIsInBlcnNvbklkIjoiOTI1ZDY3Y2QtN2QzYy00MDc4LTg5ZmItNjk2M2M0N2I0OTZhIiwidXNlclVVSUQiOiI3NzViOGMzZS02NzQyLTRiMzAtYjQ0My1jN2Q2YWE2ZWM0YWMiLCJleHAiOjE1ODcwNTQ0NDYsImlhdCI6MTU4NzAxODQ0Nn0.mXkEII2Umj38VLEMt6Qxjt7zY_ljjTP79K96-239EFg";
        String patientId = "a7864f44-7ba8-4bfa-b8c2-de9afa84d30d";
        String orgUuid = "4cc74280-efe5-4016-b41e-f29472a4ec12";
        String sessionToken = "SessionId:172.31.5.13#prashant:4cc74280-efe5-4016-b41e-f29472a4ec12:MHMS:MHProfessional#1587018446217#-829001316#672";
        List<JSONObject> composition = new ArrayList<JSONObject>();

        ArrayList<List<JSONObject>> returnList = new ArrayList<List<JSONObject>>();

        JSONObject virtualFolder = new BmrUtility().getVirtualFolderByPersonId(loginToken, patientId, orgUuid);
        System.out.println(virtualFolder.toString());
        System.out.println("Iterator starts from here");
        List<String[][]> list = new BmrUtility().fetchNameTemplateIdAndCompositionUid(virtualFolder);
        Iterator itr = list.iterator();
        int index=-1;
        while(itr.hasNext()){
            index ++;
            returnList.add(new ArrayList<JSONObject>());
            String[][] nameAndTemplateId = (String[][])itr.next();
            for(int i=0; i<nameAndTemplateId.length;i++){
                String name = nameAndTemplateId[i][0];
                String templateId = nameAndTemplateId[i][1];
                String compositionIDList = nameAndTemplateId[i][2];
                //System.out.println("check here --------" + name + " " + templateId +" " + compositionIDList);
                JSONObject newComposition = new BmrUtility().getComposition(name, templateId, compositionIDList, patientId, sessionToken, loginToken);
                returnList.get(index).add(newComposition);
            }
        }

        for(List item : returnList){

            for(int i=0; i<item.size();i++){
                System.out.println(item.get(i).toString());
            }
            System.out.println("next item starts from here onwards");
        }



        System.out.println("iterator ends here");
    }

    @Test
    public void createCompositionTest() {

        Map<String, String> map = new HashMap<String, String>();
        map.put("composer_name", "prashant");
        map.put("composer_identifier", "775b8c3e-6742-4b30-b443-c7d6aa6ec4ac");
        map.put("facility_identifier", "4cc74280-efe5-4016-b41e-f29472a4ec12");
        map.put("facility_name", "psm321op");
        map.put("location", "Bengaluru");

        String loginToken = "eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3MjgxNTA0LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODcyMzgzMDQsInNlc3Npb25JZCI6ImJlYjRjZTUxLTVkNzEtNDZhZS04ZWY4LTdiM2NkNDNjZDhjMSIsInVzZXJOYW1lIjoicHJhc2hhbnQiLCJvcmdVVUlEIjoiNGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyIiwibmJmIjoxNTg3MjM4MzA0LCJvcmdSb2xlIjoiTUhQcm9mZXNzaW9uYWwiLCJzZXNzaW9uVG9rZW4iOiJTZXNzaW9uSWQ6MTcyLjMxLjUuMTMjcHJhc2hhbnQ6NGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyOk1ITVM6TUhQcm9mZXNzaW9uYWwjMTU4NzIzODMwNDQzMSM5Mzc4MDE3NiM4NzQiLCJwZXJzb25JZCI6IjkyNWQ2N2NkLTdkM2MtNDA3OC04OWZiLTY5NjNjNDdiNDk2YSIsInVzZXJVVUlEIjoiNzc1YjhjM2UtNjc0Mi00YjMwLWI0NDMtYzdkNmFhNmVjNGFjIiwiZXhwIjoxNTg3Mjc0MzA0LCJpYXQiOjE1ODcyMzgzMDR9.gHxbPt_s7ytyj5yfaYfv0x7Q9xliCVcNE1_V9Se8fos";
        String sessionToken = "";
        try {
            System.out.println(new BmrCreateCompositionUtility().createCompositionEHRC_Medication_orderv0(null, map, loginToken, sessionToken));
        } catch (Exception e) {}


    }


    @Test
    public void getDiagnosticDetailsTest() {
        String loginToken = "eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3NDAxMDk5LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODczNTc4OTksInNlc3Npb25JZCI6IjM0M2NmOWRjLWNmMTMtNGI1Yi05OTg5LTk0MGVjOTFjMzU5OCIsInVzZXJOYW1lIjoicHJhc2hhbnQiLCJvcmdVVUlEIjoiNGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyIiwibmJmIjoxNTg3MzU3ODk5LCJvcmdSb2xlIjoiTUhQcm9mZXNzaW9uYWwiLCJzZXNzaW9uVG9rZW4iOiJTZXNzaW9uSWQ6MTcyLjMxLjUuMTMjcHJhc2hhbnQ6NGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyOk1ITVM6TUhQcm9mZXNzaW9uYWwjMTU4NzM1Nzg5OTQ4NyMtMTcxNTE5ODUwNCM5MzMiLCJwZXJzb25JZCI6IjkyNWQ2N2NkLTdkM2MtNDA3OC04OWZiLTY5NjNjNDdiNDk2YSIsInVzZXJVVUlEIjoiNzc1YjhjM2UtNjc0Mi00YjMwLWI0NDMtYzdkNmFhNmVjNGFjIiwiZXhwIjoxNTg3MzkzODk5LCJpYXQiOjE1ODczNTc4OTl9.ydZc88T5EPuMHiDlhpbtl3bX1KA62gVOSUS5PyQW-Tg";
        //System.out.println(new BmrCreateCompositionUtility().getDiagdiagnosisTemplate(loginToken));
    }

    @Test
    public void createComposition_EHRC_Diagnosisv0Test() {
        String loginToken = "eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3Njg0Mjg5LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODc2NDEwODksInNlc3Npb25JZCI6IjlmYTRjMmQ5LWI5NmItNDE2YS1hZjhhLWNlNjZkMDEzNWU5NiIsInVzZXJOYW1lIjoiYXJqdW4wMSIsIm9yZ1VVSUQiOiJmZGY5NmU3Mi0xNTUwLTQ0MWUtYWU0NC05Y2QyYzllOTI4YzQiLCJuYmYiOjE1ODc2NDEwODksIm9yZ1JvbGUiOiJNSFJlZ2lzdHJ5UHJvZmVzc2lvbmFsIiwic2Vzc2lvblRva2VuIjoiU2Vzc2lvbklkOjE3Mi4zMS41LjEzI2FyanVuMDE6ZmRmOTZlNzItMTU1MC00NDFlLWFlNDQtOWNkMmM5ZTkyOGM0Ok1ITVM6TUhSZWdpc3RyeVByb2Zlc3Npb25hbCMxNTg3NjQxMDg5NTc5Iy03NzE1NTY4MDIjMTMxNCIsInBlcnNvbklkIjoiMDc0OTc2NzEtMDM5NC00ZTgwLWFiMDktOTE1ZGI3ZGU1Mzk2IiwidXNlclVVSUQiOiIzZjkxNjFhNS1lMzE4LTQzZDUtOGQ3OS0zMWI5MmYwY2EyYTMiLCJleHAiOjE1ODc2NzcwODksImlhdCI6MTU4NzY0MTA4OX0.L4CZU9h70aY075W4hnV616ovpMZoeMBV8-CAWlmW4vw";
        String sessionToken = "SessionId:172.31.5.13#arjun01:fdf96e72-1550-441e-ae44-9cd2c9e928c4:MHMS:MHRegistryProfessional#1587641089579#-771556802#1314";
        JSONObject object = new BmrCreateCompositionUtility().createComposition_EHRC_Diagnosisv0(null, null, loginToken, sessionToken);
        System.out.println(object);
    }

    @Test
    public void test() {
        Map<String, String> map = new HashMap<String, String>();
        map.put("composer_name", "arjun01");
        map.put("composer_identifier", "3f9161a5-e318-43d5-8d79-31b92f0ca2a3");
        map.put("facility_identifier", "fdf96e72-1550-441e-ae44-9cd2c9e928c4");
        map.put("facility_name", "National Institute of PsychiatryONE");
        map.put("location", "Bengaluru");
        map.put("personId", "bc512b38-80d4-4eba-9f45-58480ca4a45d");

        String loginToken = "eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3Njg0Mjg5LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODc2NDEwODksInNlc3Npb25JZCI6IjlmYTRjMmQ5LWI5NmItNDE2YS1hZjhhLWNlNjZkMDEzNWU5NiIsInVzZXJOYW1lIjoiYXJqdW4wMSIsIm9yZ1VVSUQiOiJmZGY5NmU3Mi0xNTUwLTQ0MWUtYWU0NC05Y2QyYzllOTI4YzQiLCJuYmYiOjE1ODc2NDEwODksIm9yZ1JvbGUiOiJNSFJlZ2lzdHJ5UHJvZmVzc2lvbmFsIiwic2Vzc2lvblRva2VuIjoiU2Vzc2lvbklkOjE3Mi4zMS41LjEzI2FyanVuMDE6ZmRmOTZlNzItMTU1MC00NDFlLWFlNDQtOWNkMmM5ZTkyOGM0Ok1ITVM6TUhSZWdpc3RyeVByb2Zlc3Npb25hbCMxNTg3NjQxMDg5NTc5Iy03NzE1NTY4MDIjMTMxNCIsInBlcnNvbklkIjoiMDc0OTc2NzEtMDM5NC00ZTgwLWFiMDktOTE1ZGI3ZGU1Mzk2IiwidXNlclVVSUQiOiIzZjkxNjFhNS1lMzE4LTQzZDUtOGQ3OS0zMWI5MmYwY2EyYTMiLCJleHAiOjE1ODc2NzcwODksImlhdCI6MTU4NzY0MTA4OX0.L4CZU9h70aY075W4hnV616ovpMZoeMBV8-CAWlmW4vw";
        String sessionToken = "SessionId:172.31.5.13#arjun01:fdf96e72-1550-441e-ae44-9cd2c9e928c4:MHMS:MHRegistryProfessional#1587641089579#-771556802#1314";

        BmrCreateCompositionUtility object = new BmrCreateCompositionUtility();
        String[] values = {"a", "b", "c", "d", "e", "f"};
        System.out.println(object.createComposition_EHRC_Service_requestv0(values, map, loginToken, sessionToken).toString());
    }


    @Test
    public void createAllComposition() {


            String complaints = "new new complaints";
            String duration = "new new duration";

            String history = "new new history";

            String summaryOfIllness = "new new summary of illness";

            String diagnosisType = "Differential Diagnosis";
            String ICD_Description = "new desc";
            String ICD_10_Code = "new code";

            String improvementStatus = "2|local::at0027|Very much improved|";

            String medicineName = "new new medicine name";
            String dosage = "new new dosage";
            String dosingTime = "new new dosing time";
            String medDuration = "10";
            String durationType = "months";
            String remarks = "new new remarks";
            String[] medicationOrder = {medicineName, dosage, dosingTime, medDuration, durationType, remarks};

            String treatmentInstruction = "new new instruction";


        boolean referral  = true;
        boolean followUp = false;


        Map<String, String> map = new HashMap<String, String>();
        map.put("composer_name", "arjun01");
        map.put("composer_identifier", "3f9161a5-e318-43d5-8d79-31b92f0ca2a3");
        map.put("facility_identifier", "fdf96e72-1550-441e-ae44-9cd2c9e928c4");
        map.put("facility_name", "National Institute of PsychiatryONE");
        map.put("location", "Bengaluru");
        map.put("personId", "bc512b38-80d4-4eba-9f45-58480ca4a45d");

        String loginToken = "eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3NjcxOTk3LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODc2Mjg3OTcsInNlc3Npb25JZCI6Ijk0ODJlNzRlLWI4MDEtNDhkZi1hNDM5LWYzNTZmYzk1MDc4YyIsInVzZXJOYW1lIjoiYXJqdW4wMSIsIm9yZ1VVSUQiOiJmZGY5NmU3Mi0xNTUwLTQ0MWUtYWU0NC05Y2QyYzllOTI4YzQiLCJuYmYiOjE1ODc2Mjg3OTcsIm9yZ1JvbGUiOiJNSFJlZ2lzdHJ5UHJvZmVzc2lvbmFsIiwic2Vzc2lvblRva2VuIjoiU2Vzc2lvbklkOjE3Mi4zMS41LjEzI2FyanVuMDE6ZmRmOTZlNzItMTU1MC00NDFlLWFlNDQtOWNkMmM5ZTkyOGM0Ok1ITVM6TUhSZWdpc3RyeVByb2Zlc3Npb25hbCMxNTg3NjI4Nzk3MzY3IzI0Nzg0OTc1NCMxMjc4IiwicGVyc29uSWQiOiIwNzQ5NzY3MS0wMzk0LTRlODAtYWIwOS05MTVkYjdkZTUzOTYiLCJ1c2VyVVVJRCI6IjNmOTE2MWE1LWUzMTgtNDNkNS04ZDc5LTMxYjkyZjBjYTJhMyIsImV4cCI6MTU4NzY2NDc5NywiaWF0IjoxNTg3NjI4Nzk3fQ.0Q5X-K7eRUO-uZYb8bKm-AvgZt5-Ad1NRWalPQ9je-I";
        String sessionToken = "SessionId:172.31.5.13#arjun01:fdf96e72-1550-441e-ae44-9cd2c9e928c4:MHMS:MHRegistryProfessional#1587628797367#247849754#1278";

        BmrCreateCompositionUtility utility = new BmrCreateCompositionUtility();
        JSONArray arr = new JSONArray();

        HashMap<String[], JSONObject> allCompositions = new HashMap<String[], JSONObject>();
        List<Composition> list = new ArrayList<Composition>();


        System.out.println("Entering try");
        System.out.println(utility.createComposition_EHRC_Diagnosisv0(new String[]{diagnosisType, ICD_Description, ICD_10_Code}, map, loginToken, sessionToken));

        try {
            System.out.println("inside try");
     //0       arr.put(0, utility.createComposition_EHRC_Complaintsv0(new String[]{complaints, duration}, map, loginToken, sessionToken));
            list.add(new Composition("complaints_matches_compositionIDs", "EHRC - Complaints.v0", utility.createComposition_EHRC_Complaintsv0(new String[]{complaints, duration}, map, loginToken, sessionToken).getString("compositionUid")));

    //1        arr.put(1, utility.createComposition_EHRC_Diagnosisv0(new String[]{diagnosisType, ICD_Description, ICD_10_Code}, map, loginToken, sessionToken));

            list.add(new Composition("diagnosis_matches_compositionIDs", "EHRC - Diagnosis.v0", utility.createComposition_EHRC_Diagnosisv0(new String[]{diagnosisType, ICD_Description, ICD_10_Code}, map, loginToken, sessionToken).getString("compositionUid")));

     //2       arr.put(2, utility.createCompostion_EHRC_Clinical_historyv0(history, map, loginToken, sessionToken));

            list.add(new Composition("clinical_history_matches_compositionIDs", "EHRC - Clinical history.v0", utility.createCompostion_EHRC_Clinical_historyv0(history, map, loginToken, sessionToken).getString("compositionUid")));

    //3        arr.put(3, utility.createComposition_EHRC_Summary_of_illnessv0(summaryOfIllness, map, loginToken, sessionToken));

            list.add(new Composition("summary_of_illness_matches_compositionIDs", "EHRC - Summary of illness.v0", utility.createComposition_EHRC_Summary_of_illnessv0(summaryOfIllness, map, loginToken, sessionToken).getString("compositionUid")));


    //4        arr.put(4, utility.createCompositionEHRC_Clinical_notesv0(treatmentInstruction, map, loginToken, sessionToken));

            list.add(new Composition("clinical_notes_order_matches_compositionIDs", "EHRC - Clinical notes.v0", utility.createCompositionEHRC_Clinical_notesv0(treatmentInstruction, map, loginToken, sessionToken).getString("compositionUid")));
    //5        arr.put(5, utility.createCompositionEHRC_Medication_orderv0(new String[]{medicineName, dosage, dosingTime, medduration, durationType, remarks}, map, loginToken, sessionToken));


            list.add(new Composition("medication_order_matches_compositionIDs", "EHRC - Medication order.v0", utility.createCompositionEHRC_Medication_orderv0(medicationOrder, map, loginToken, sessionToken).getString("compositionUid")));

    //6        arr.put(6, utility.createComposition_EHRC_CGI_Scalev0(improvementStatus, map, loginToken, sessionToken));


            list.add(new Composition("cgi_scale_matches_compositionIDs", "EHRC - CGI Scale.v0", utility.createComposition_EHRC_CGI_Scalev0(improvementStatus, map, loginToken, sessionToken).getString("compositionUid")));

            if(referral) {
                String[] referralValues = {"a", "b", "c", "Referral", "e", "f"};
                list.add(new Composition("service_request_matches_compositionIDs", "EHRC - Service request.v0","Referral", utility.createComposition_EHRC_Service_requestv0(referralValues, map, loginToken, sessionToken).getString("compositionUid")));
            } else if(followUp) {
                String[] followUpValues = {"2020-04-23T04:56:46.793Z::2020-04-24T18:30:00.000Z", "Followup"};
                list.add(new Composition("service_request_matches_compositionIDs", "EHRC - Service request.v0", "Followup", utility.createComposition_EHRC_Service_requestv01(followUpValues, map, loginToken, sessionToken).getString("compositionUid")));
            }

        } catch (Exception e) {e.printStackTrace();}
        System.out.println("ouside try");


        for(int i=0;i<list.size();i++) {
            Composition object = list.get(i);
            System.out.println(object.getName()+"    "+object.getTemplateId()+"     "+object.getCompositionUid());
        }

        System.out.println("4444444444444444444444444444444444444444444444444444444444444");
        System.out.println(utility.saveAllCompositions(map, list, loginToken, sessionToken));
        System.out.println("4444444444444444444444444444444444444444444444444444444444444");

        MHPAssignmentUtility util = new MHPAssignmentUtility();
        try{
                new MHPAssignmentUtility().updateIPPatientQueue(util.getPatientByPatientId(loginToken, sessionToken,map.get("personId")), util.getParentOrg(loginToken), util.getRegisteredMHPs(loginToken).getJSONObject(0), loginToken, "Completed");
        } catch (Exception e) {e.printStackTrace();}

    }


}
/*
orgUUID: "4cc74280-efe5-4016-b41e-f29472a4ec12"
patientId: "25424093-ef2c-4ff4-a6a4-09afc1fb8c08"
token: "SessionId:172.31.5.13#prashant:4cc74280-efe5-4016-b41e-f29472a4ec12:MHMS:MHProfessional#1587320325633#-100404299#922"
uidata: [,…]
0: {time: 1587320422053, name: "complaints_matches_compositionIDs", templateId: "EHRC - Complaints.v0",…}
compositionUid: "1510923d-8145-4b04-b6a0-2b870dc89950::ehr.ehr.network::1"
name: "complaints_matches_compositionIDs"
templateId: "EHRC - Complaints.v0"
time: 1587320422053
1: {name: "diagnosis_matches_compositionIDs", templateId: "EHRC - Diagnosis.v0", time: 1587320423364,…}
compositionUid: "4b8e49f7-da9e-4b9e-aee4-3181358780d1::ehr.ehr.network::1"
name: "diagnosis_matches_compositionIDs"
templateId: "EHRC - Diagnosis.v0"
time: 1587320423364
2: {name: "clinical_history_matches_compositionIDs", templateId: "EHRC - Clinical history.v0",…}
compositionUid: "09aa995c-47e1-4c2a-ab88-7f3bcc7929ca::ehr.ehr.network::1"
name: "clinical_history_matches_compositionIDs"
templateId: "EHRC - Clinical history.v0"
3: {name: "summary_of_illness_matches_compositionIDs", templateId: "EHRC - Summary of illness.v0",…}
compositionUid: "1aef7065-855c-4148-9bac-a2e28f442f49::ehr.ehr.network::1"
name: "summary_of_illness_matches_compositionIDs"
templateId: "EHRC - Summary of illness.v0"
4: {templateId: "EHRC - Clinical notes.v0", name: "clinical_notes_order_matches_compositionIDs",…}
compositionUid: "d4ca40db-1434-44f5-9327-203237c3a321::ehr.ehr.network::1"
name: "clinical_notes_order_matches_compositionIDs"
templateId: "EHRC - Clinical notes.v0"
5: {name: "medication_order_matches_compositionIDs", templateId: "EHRC - Medication order.v0",…}
compositionUid: "7e3c6ab1-3212-4878-ad03-f79459db9077::ehr.ehr.network::1"
name: "medication_order_matches_compositionIDs"
templateId: "EHRC - Medication order.v0"
time: 1587320425199
6: {name: "cgi_scale_matches_compositionIDs", templateId: "EHRC - CGI Scale.v0",…}
compositionUid: "c5f4b68b-7c16-4969-9730-0e1715e3ac90::ehr.ehr.network::1"
name: "cgi_scale_matches_compositionIDs"
templateId: "EHRC - CGI Scale.v0"
uuid: "775b8c3e-6742-4b30-b443-c7d6aa6ec4ac"
 */