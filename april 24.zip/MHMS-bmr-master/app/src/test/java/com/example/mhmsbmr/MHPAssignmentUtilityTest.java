package com.example.mhmsbmr;


import com.example.mhmsbmr.utility.MHPAssignmentUtility;


import org.json.JSONObject;
import org.junit.Test;

public class MHPAssignmentUtilityTest {

    @Test
    public void getAvailableMHPsTest() {
        new MHPAssignmentUtility().getRegisteredMHPs("eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3NTA2OTQ4LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODc0NjM3NDgsInNlc3Npb25JZCI6IjAzMmEwNjllLTZiNDItNDI4OS1hMDg2LTE1Njc3NzgxNDAyYyIsInVzZXJOYW1lIjoicHJhc2hhbnQiLCJvcmdVVUlEIjoiNGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyIiwibmJmIjoxNTg3NDYzNzQ4LCJvcmdSb2xlIjoiTUhQcm9mZXNzaW9uYWwiLCJzZXNzaW9uVG9rZW4iOiJTZXNzaW9uSWQ6MTcyLjMxLjUuMTMjcHJhc2hhbnQ6NGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyOk1ITVM6TUhQcm9mZXNzaW9uYWwjMTU4NzQ2Mzc0NzgxNyMtMTE2OTAyNzU2NSMxMDg1IiwicGVyc29uSWQiOiI5MjVkNjdjZC03ZDNjLTQwNzgtODlmYi02OTYzYzQ3YjQ5NmEiLCJ1c2VyVVVJRCI6Ijc3NWI4YzNlLTY3NDItNGIzMC1iNDQzLWM3ZDZhYTZlYzRhYyIsImV4cCI6MTU4NzQ5OTc0OCwiaWF0IjoxNTg3NDYzNzQ4fQ.s2VgP85_GB1-KC_Uc9JKI4rzZXW5nhdGGG3LcpI_IAQ");

    }

    @Test
    public void getPatentOrgTest() {
        new MHPAssignmentUtility().getParentOrg("eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3NTA1NjYxLCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODc0NjI0NjEsInNlc3Npb25JZCI6IjI5MTQ0N2M3LTMxMjAtNDVjZi05MjdiLWJmMDRkNjg0MDQ2NSIsInVzZXJOYW1lIjoicHJhc2hhbnQiLCJvcmdVVUlEIjoiNGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyIiwibmJmIjoxNTg3NDYyNDYxLCJvcmdSb2xlIjoiTUhQcm9mZXNzaW9uYWwiLCJzZXNzaW9uVG9rZW4iOiJTZXNzaW9uSWQ6MTcyLjMxLjUuMTMjcHJhc2hhbnQ6NGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyOk1ITVM6TUhQcm9mZXNzaW9uYWwjMTU4NzQ2MjQ2MDgwNSMxNjgxNzYzOTgwIzEwODAiLCJwZXJzb25JZCI6IjkyNWQ2N2NkLTdkM2MtNDA3OC04OWZiLTY5NjNjNDdiNDk2YSIsInVzZXJVVUlEIjoiNzc1YjhjM2UtNjc0Mi00YjMwLWI0NDMtYzdkNmFhNmVjNGFjIiwiZXhwIjoxNTg3NDk4NDYxLCJpYXQiOjE1ODc0NjI0NjF9.eR3rWVHC3dJsVEzOhqYLdUsa8Vk9nUTYmSR06hbY9AE");
    }


    @Test
    public void getPatientAgeTest() {
        new MHPAssignmentUtility().getPatientAge("eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3MTU0MDQyLCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODcxMTA4NDIsInNlc3Npb25JZCI6IjkxMTRiMjYxLWRiYjMtNDdmNC1iNmUzLTliYWYwYjNmNWUyNCIsInVzZXJOYW1lIjoicHJhc2hhbnQiLCJvcmdVVUlEIjoiNGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyIiwibmJmIjoxNTg3MTEwODQyLCJvcmdSb2xlIjoiTUhQcm9mZXNzaW9uYWwiLCJzZXNzaW9uVG9rZW4iOiJTZXNzaW9uSWQ6MTcyLjMxLjUuMTMjcHJhc2hhbnQ6NGNjNzQyODAtZWZlNS00MDE2LWI0MWUtZjI5NDcyYTRlYzEyOk1ITVM6TUhQcm9mZXNzaW9uYWwjMTU4NzExMDg0MTg2MCM4MDg1OTc0NzYjODAyIiwicGVyc29uSWQiOiI5MjVkNjdjZC03ZDNjLTQwNzgtODlmYi02OTYzYzQ3YjQ5NmEiLCJ1c2VyVVVJRCI6Ijc3NWI4YzNlLTY3NDItNGIzMC1iNDQzLWM3ZDZhYTZlYzRhYyIsImV4cCI6MTU4NzE0Njg0MiwiaWF0IjoxNTg3MTEwODQyfQ.S0AItkRK9ZoDycNtRwZOr1Fa530ZfnirIv5g4uxW2No", "2000-12-30T18:30:00.000Z");
    }


    @Test
    public void updateIPPatientQueueTest() {

        String loginToken = "eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3NjcxOTk3LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODc2Mjg3OTcsInNlc3Npb25JZCI6Ijk0ODJlNzRlLWI4MDEtNDhkZi1hNDM5LWYzNTZmYzk1MDc4YyIsInVzZXJOYW1lIjoiYXJqdW4wMSIsIm9yZ1VVSUQiOiJmZGY5NmU3Mi0xNTUwLTQ0MWUtYWU0NC05Y2QyYzllOTI4YzQiLCJuYmYiOjE1ODc2Mjg3OTcsIm9yZ1JvbGUiOiJNSFJlZ2lzdHJ5UHJvZmVzc2lvbmFsIiwic2Vzc2lvblRva2VuIjoiU2Vzc2lvbklkOjE3Mi4zMS41LjEzI2FyanVuMDE6ZmRmOTZlNzItMTU1MC00NDFlLWFlNDQtOWNkMmM5ZTkyOGM0Ok1ITVM6TUhSZWdpc3RyeVByb2Zlc3Npb25hbCMxNTg3NjI4Nzk3MzY3IzI0Nzg0OTc1NCMxMjc4IiwicGVyc29uSWQiOiIwNzQ5NzY3MS0wMzk0LTRlODAtYWIwOS05MTVkYjdkZTUzOTYiLCJ1c2VyVVVJRCI6IjNmOTE2MWE1LWUzMTgtNDNkNS04ZDc5LTMxYjkyZjBjYTJhMyIsImV4cCI6MTU4NzY2NDc5NywiaWF0IjoxNTg3NjI4Nzk3fQ.0Q5X-K7eRUO-uZYb8bKm-AvgZt5-Ad1NRWalPQ9je-I";
        String sessionToken = "SessionId:172.31.5.13#arjun01:fdf96e72-1550-441e-ae44-9cd2c9e928c4:MHMS:MHRegistryProfessional#1587628797367#247849754#1278";

        MHPAssignmentUtility utility = new MHPAssignmentUtility();
        JSONObject patient = utility.getPatientByPatientId(loginToken, sessionToken, "bc512b38-80d4-4eba-9f45-58480ca4a45d");
        JSONObject parentOrg = utility.getParentOrg(loginToken);
        JSONObject MHP=null;
        try {
            System.out.println("total number of professionals = "+utility.getRegisteredMHPs(loginToken).length());
            //int index = new Scanner(System.in).nextInt();
            MHP = utility.getRegisteredMHPs(loginToken).getJSONObject(0);
        } catch(Exception e){e.printStackTrace();}
        utility.updateIPPatientQueue(patient, parentOrg, MHP, loginToken);
    }

    @Test
    public void updateIPPatientQueueTestCompleted() {

        String loginToken = "eyJEZXZlbG9wZWQgQnkiOiJlLUhlYWx0aCBSZXNlYXJjaCBDZW50ZXIsIElJSVQgQmFuZ2Fsb3JlIiwiSG9zdCI6Ikthcm5hdGFrYSBNZW50YWwgSGVhbHRoIE1hbmFnZW1lbnQgU3lzdGVtIiwidHlwIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJwcm9mZXNzaW9uIjoiTUhNU1BzeWNoaWF0cmlzdCIsInN1YiI6Ik1ITVMgU2VjdXJpdHkgVG9rZW4iLCJsYXN0TG9naW5PcmdJZCI6ImEyMWI4ODVlLTJmM2EtNDQyNS04YjViLTBkMjc0YjQyYWYyNiIsInNlc3Npb25FbmRUaW1lIjoxNTg3NjcxOTk3LCJpc3MiOiJLTUhNUyIsInNlc3Npb25TdGFydFRpbWUiOjE1ODc2Mjg3OTcsInNlc3Npb25JZCI6Ijk0ODJlNzRlLWI4MDEtNDhkZi1hNDM5LWYzNTZmYzk1MDc4YyIsInVzZXJOYW1lIjoiYXJqdW4wMSIsIm9yZ1VVSUQiOiJmZGY5NmU3Mi0xNTUwLTQ0MWUtYWU0NC05Y2QyYzllOTI4YzQiLCJuYmYiOjE1ODc2Mjg3OTcsIm9yZ1JvbGUiOiJNSFJlZ2lzdHJ5UHJvZmVzc2lvbmFsIiwic2Vzc2lvblRva2VuIjoiU2Vzc2lvbklkOjE3Mi4zMS41LjEzI2FyanVuMDE6ZmRmOTZlNzItMTU1MC00NDFlLWFlNDQtOWNkMmM5ZTkyOGM0Ok1ITVM6TUhSZWdpc3RyeVByb2Zlc3Npb25hbCMxNTg3NjI4Nzk3MzY3IzI0Nzg0OTc1NCMxMjc4IiwicGVyc29uSWQiOiIwNzQ5NzY3MS0wMzk0LTRlODAtYWIwOS05MTVkYjdkZTUzOTYiLCJ1c2VyVVVJRCI6IjNmOTE2MWE1LWUzMTgtNDNkNS04ZDc5LTMxYjkyZjBjYTJhMyIsImV4cCI6MTU4NzY2NDc5NywiaWF0IjoxNTg3NjI4Nzk3fQ.0Q5X-K7eRUO-uZYb8bKm-AvgZt5-Ad1NRWalPQ9je-I";
        String sessionToken = "SessionId:172.31.5.13#arjun01:fdf96e72-1550-441e-ae44-9cd2c9e928c4:MHMS:MHRegistryProfessional#1587628797367#247849754#1278";

        MHPAssignmentUtility utility = new MHPAssignmentUtility();
        JSONObject patient = utility.getPatientByPatientId(loginToken, sessionToken, "bc512b38-80d4-4eba-9f45-58480ca4a45d");
        JSONObject parentOrg = utility.getParentOrg(loginToken);
        JSONObject MHP=null;
        try {
            System.out.println("total number of professionals = "+utility.getRegisteredMHPs(loginToken).length());
            //int index = new Scanner(System.in).nextInt();
            MHP = utility.getRegisteredMHPs(loginToken).getJSONObject(0);
        } catch(Exception e){e.printStackTrace();}
        utility.updateIPPatientQueue(patient, parentOrg, MHP, loginToken, "Completed");
    }



}
