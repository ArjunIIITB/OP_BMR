package com.example.mhmsbmr.Login;

public class GlobalVariables {

    public static final String GLOBAL_PATH_REST =  "http://13.126.27.50/MHMS_DEV/rest/";
    public static final String GLOBAL_PATH_USER =  "http://13.126.27.50/MHMS_DEV/user/";


    public static final String PUBLIC_KEY = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAyPn1HQbJrZkJmPC2ogDr\n" +
            " 16ZMCpnQxVLHER/Uyz1ynFp7jHWn69wtKYI+n03IQobU0R7w4Y33KiBN545O2uaB\n" +
            " YJOCD0nVpv7YvCr5y9BRzDcBaIbFPJYPz0x25x9KhSykHSJHkO1r13VzG24mGnti\n" +
            " V1a8V3+6YhwKJ52238ZjSTRStHdD5lIS2rdTdi7HFi6ZnFAzaH/0N/hrGABMs/Jz\n" +
            " UC2LJ2vCBJIaZdMGMnkP8bA+gWX3/iUEQ7vBBV0USsMyxHtRS7q7EJ7oEg2R9k4W\n" +
            " Zz9T1u3k7cgAXCHVuz5LiCbH8nQoKudpk5CsjXLMow/Y2OJNhnFEGNbx2po78UnX\n" +
            " 1yLZlALt2qgWXkp3gZynSqumoplkCKlpYyFttQZuSOyM3JfFqyZ9OkRvGhIrPcbx\n" +
            " VyWZfYCaKiTENT1pTWybxbVHcwpFfJ3qsJUb5MqZpV6/83zB6OpZr5WzY8OWjiLM\n" +
            " cXIqY5CLz6IRKqyJ155dsFDhRlK4zC+skAGV2t5yba94yuffPFIRmqFhEvrBgT8z\n" +
            " 9Ukg6+HHNA1urNO58YA9kvoMXTDIeznPfDg5xtvaSiHTrvJ24pX53tc+5yMgVFJw\n" +
            " 2lMZihoe5rSkV6hnvqouW2kYpEdmuanpqWbYmiQ/X+zX/Al0i3D2oLxdGVSkBwsH\n" +
            " ExWRXpa1gWTz3VfI+LevQIkCAwEAAQ==";

}
