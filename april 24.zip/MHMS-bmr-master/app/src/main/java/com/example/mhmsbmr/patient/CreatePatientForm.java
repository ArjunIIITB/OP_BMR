package com.example.mhmsbmr.patient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.mhmsbmr.Login.GlobalVariables;
import com.example.mhmsbmr.Login.MHPFlow;
import com.example.mhmsbmr.R;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class CreatePatientForm extends AppCompatActivity {


    String orgUUID;
    String userUUID;
    String userToken;

    EditText patient_name;
    EditText id_number;

    String name;
    String idNumber;

    JSONObject OTPResponse ;

    JSONObject jsonObject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_patient_form);

    } //onCreate method


    public JSONObject sendOTP(View v) {

        Thread thread = new Thread() {

            public void run() {


                EditText mobileText = (EditText) findViewById(R.id.editText18);

                String contactVal = mobileText.getText().toString();
                /*contactType: "mobile"
                contactVal: "8404973134"
                purpose: "CONSENT"*/
                OkHttpClient client = new OkHttpClient();
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                final String loginToken = sharedPreferences.getString("loginToken", "");


                final String RELATIVE_PATH = "sendOTP/";

                final MediaType JSON
                        = MediaType.parse("application/json; charset=utf-8");


                JSONObject jsonObject = new JSONObject();
                try {

                    jsonObject.put("contactType", "mobile");
                    jsonObject.put("contactVal", contactVal);
                    jsonObject.put("purpose", "CONSENT");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                RequestBody formBody = RequestBody.create(JSON, jsonObject.toString());

                Request request = new Request.Builder()
                        .url(GlobalVariables.GLOBAL_PATH_USER + RELATIVE_PATH)
                        .post(formBody)
                        .addHeader("Authorization", "Bearer " + loginToken)
                        .addHeader("Content-Type", "application/json")
                        .build();

                Response response = null;

                try {
                    response = client.newCall(request).execute();
                    ResponseBody rb = response.body();
                    //System.out.println(rb.string());
                    OTPResponse = new JSONObject(rb.string());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();

        return OTPResponse;

    } // sendOTP method



    public void verifyOTP(View v) {

        /*contactType: "mobile"
        contactVal: "8404973134"
        purpose: "CONSENT"*/

        Thread thread = new Thread() {


            public void run() {

                OkHttpClient client = new OkHttpClient();
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                final String loginToken = sharedPreferences.getString("loginToken", "");


                final String RELATIVE_PATH = "verifyOTP/";
                final MediaType JSON
                        = MediaType.parse("application/json; charset=utf-8");


                JSONObject jsonObject = OTPResponse;
                try {

                    Log.e("The OTPResponse Object ", OTPResponse.toString());

                    EditText OTP = (EditText) findViewById(R.id.editText19);
                    String otp = OTP.getText().toString();

                    Log.e("OTP----------", otp);

                    jsonObject.remove("otp");
                    jsonObject.put("otp", otp);

                } catch (Exception e) {
                    e.printStackTrace();
                }
                RequestBody formBody = RequestBody.create(JSON, jsonObject.toString());

                Request request = new Request.Builder()
                        .url(GlobalVariables.GLOBAL_PATH_USER + RELATIVE_PATH)
                        .post(formBody)
                        .addHeader("Authorization", "Bearer " + loginToken)
                        .addHeader("Content-Type", "application/json")
                        .build();

                Response response = null;

                try {
                    response = client.newCall(request).execute();
                    ResponseBody rb = response.body();
                    System.out.println(rb.string());

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();

    } // verifyOTP method



    public void createPatient(View v){

        patient_name = findViewById(R.id.editText5);
        name = patient_name.getText().toString();
        id_number = findViewById(R.id.idNumber);
        idNumber = id_number.getText().toString();


        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        final String loginToken = sharedPreferences.getString("loginToken", "");
        try {
            String loginDecodedToken = MHPFlow.decoded(loginToken);
            Log.e("loginDecodedToken", loginDecodedToken);
            orgUUID = new JSONObject(loginDecodedToken).getString("orgUUID");
            userUUID = new JSONObject(loginDecodedToken).getString("userUUID");
            userToken = new JSONObject(loginDecodedToken).getString("sessionToken");


            jsonObject = new JSONObject();

            jsonObject.put("userToken", userToken);
            jsonObject.put("userUuid", userUUID);
            jsonObject.put("orgUuid", orgUUID);
            jsonObject.put("idType", "AB-ARK ID");
            Log.e("id number", idNumber);
            jsonObject.put("idNumber", idNumber);
            jsonObject.put("prefix", "Mr.");
            Log.e("patient name", name);
            jsonObject.put("givenName", name);
            jsonObject.put("middleName", "middleThree");

            JSONObject genderObject = new JSONObject();
            genderObject.put("genderCode", "Male");

            jsonObject.put("gender", genderObject);

            JSONObject emergencyContactObject = new JSONObject();
            emergencyContactObject.put("contactName", "Mr. Father");
            emergencyContactObject.put("telephone", "1234567890");

            jsonObject.put("emergencyContact", emergencyContactObject);
            jsonObject.put("phoneNumber", "8404973134");
            jsonObject.put("email", "aakrisht.arjun@iiitb.ac.in");
            jsonObject.put("dateOfBirth", "2000-12-30T18:30:00.000Z");
            jsonObject.put("status", "Visiting");

            JSONObject addressObject = new JSONObject();
            addressObject.put("district", "Bagalkot");
            addressObject.put("city", "Becgaluru");
            addressObject.put("state", "Karnataka");
            addressObject.put("pinCode", "444444");
            addressObject.put("postalCode", "444444");
            addressObject.put("address1", "Electronic City");
            addressObject.put("address2", "Phase two");

            JSONArray addressArrayObject = new JSONArray();
            addressArrayObject.put(addressObject);

            jsonObject.put("address", addressArrayObject);

            String tokenId = OTPResponse.getString("tokenID");

            jsonObject.put("mobToken", tokenId);

            Log.e("create patient mobToken", tokenId);

            Thread thread = new Thread() {

                public void run() {


                    OkHttpClient client = new OkHttpClient();


                    final String RELATIVE_PATH = "createpatient/";
                    String returnString = null;
                    final MediaType JSON
                            = MediaType.parse("application/json; charset=utf-8");


                    RequestBody formBody = RequestBody.create(JSON, jsonObject.toString());

                    Request request = new Request.Builder()
                            .url(GlobalVariables.GLOBAL_PATH_REST + RELATIVE_PATH)
                            .post(formBody)
                            .addHeader("Authorization", "Bearer " + loginToken)
                            .addHeader("Content-Type", "application/json")
                            .build();

                    Response response = null;

                    try {
                        response = client.newCall(request).execute();
                        ResponseBody rb = response.body();
                        System.out.println(rb.string());

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            };

            thread.start();

        } catch(Exception e) {e.printStackTrace();}



    } // createPatient method



} // CreatePatientForm class
